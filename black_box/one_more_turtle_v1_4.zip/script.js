// USE help() TO ASK THE TURTLE FOR HELP
'use strict'
console.log('script.js is ready')
