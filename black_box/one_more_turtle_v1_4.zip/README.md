# One more turtle v1.4 :)

Inspired by [hanumanum](https://github.com/hanumanum/js-turtle).
