# One more turtle v1.5 :)

Inspired by [hanumanum](https://github.com/hanumanum/js-turtle).
