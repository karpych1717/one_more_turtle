# One more turtle v1.1 :)

Inspired by [hanumanum](https://github.com/hanumanum/js-turtle).
